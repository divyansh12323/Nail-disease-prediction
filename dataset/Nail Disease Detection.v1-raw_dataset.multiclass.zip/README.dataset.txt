# Nail Disease Detection > raw_dataset
https://universe.roboflow.com/object-detection/nail-disease-detection-mxoqy

Provided by Roboflow
License: CC BY 4.0

